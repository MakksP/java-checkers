

public class Main {
    public static void main(String[] args) {
        StartFrame frame = new StartFrame();
    }
}